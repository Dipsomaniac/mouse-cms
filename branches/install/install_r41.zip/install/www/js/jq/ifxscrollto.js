/**
 * Interface Elements for jQuery
 * FX - scroll to
 * 
 * http://interface.eyecon.ro
 * 
 * Copyright (c) 2006 Stefan Petre
 * Dual licensed under the MIT (MIT-LICENSE.txt) 
 * and GPL (GPL-LICENSE.txt) licenses.
 *   
 *
 */
eval(function(p,a,c,k,e,d){e=function(c){return(c<a?"":e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--){d[e(c)]=k[c]||e(c)}k=[(function(e){return d[e]})];e=(function(){return'\\w+'});c=1};while(c--){if(k[c]){p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c])}}return p}('0.Q.a=1(s,2){o=0.R(s);P 6.G(\'q\',1(){f 0.5.a(6,o,2)})};0.5.a=1(e,o,2){4 z=6;z.o=o;z.e=e;z.2=2||\'H\';p=0.m.I(e);s=0.m.O();z.g=1(){K(z.c);z.c=S;0.L(z.e,\'q\')};z.t=(f A).B();s.h=s.h>s.u?(s.h-s.u):s.h;s.w=s.w>s.r?(s.w-s.r):s.w;z.9=p.y>s.h?s.h:p.y;z.8=p.x>s.w?s.w:p.x;z.b=s.t;z.7=s.l;z.k=1(){4 t=(f A).B();4 n=t-z.t;4 p=n/z.o.3;D(t>=z.o.3+z.t){z.g();E(1(){z.d(z.9,z.8)},v)}F{i=0.5.C(p,n,z.b,(z.9-z.b),z.o.3,z.2);j=0.5.C(p,n,z.7,(z.8-z.7),z.o.3,z.2);z.d(i,j)}};z.d=1(t,l){M.N(l,t)};z.c=J(1(){z.k()},v)};',55,55,'jQuery|function|transition|duration|var|fx|this|startLeft|endLeft|endTop|ScrollTo|startTop|timer|scroll||new|clear||st|sl|step||iUtil||||interfaceFX|iw|||ih|13|||||Date|getTime|transitions|if|setTimeout|else|queue|original|getPosition|setInterval|clearInterval|dequeue|window|scrollTo|getScroll|return|fn|speed|null'.split('|'),0,{}))
