﻿-- phpMyAdmin SQL Dump
-- version 2.6.1
-- http://www.phpmyadmin.net
-- 
-- Хост: localhost
-- Время создания: Дек 07 2006 г., 20:46
-- Версия сервера: 4.1.16
-- Версия PHP: 4.4.4
-- 
-- БД: `mouse2`
-- 

-- --------------------------------------------------------

-- 
-- Структура таблицы `acl`
-- 

DROP TABLE IF EXISTS `acl`;
CREATE TABLE `acl` (
  `acl_id` int(10) unsigned NOT NULL auto_increment,
  `object_id` int(10) unsigned NOT NULL default '0',
  `auser_id` int(10) unsigned NOT NULL default '0',
  `rights` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`acl_id`),
  KEY `auser_id` (`auser_id`,`object_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=9 ;

-- 
-- Дамп данных таблицы `acl`
-- 

INSERT INTO `acl` VALUES (8, 80, 2, 143);
INSERT INTO `acl` VALUES (7, 79, 2, 143);

-- --------------------------------------------------------

-- 
-- Структура таблицы `aevent_log`
-- 

DROP TABLE IF EXISTS `aevent_log`;
CREATE TABLE `aevent_log` (
  `aevent_log_id` int(10) unsigned NOT NULL auto_increment,
  `auser_id` int(10) unsigned NOT NULL default '0',
  `event_type` mediumint(9) NOT NULL default '256',
  `stat` mediumint(9) NOT NULL default '0',
  `dt` datetime NOT NULL default '0000-00-00 00:00:00',
  `content` varchar(255) collate utf8_bin default NULL,
  PRIMARY KEY  (`aevent_log_id`),
  KEY `ix_aevent_log_0` (`auser_id`,`dt`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=5 ;

-- 
-- Дамп данных таблицы `aevent_log`
-- 

INSERT INTO `aevent_log` VALUES (1, 3, 1, 0, '2006-12-05 12:18:35', 0x3132372e302e302e313a4e554c4c);
INSERT INTO `aevent_log` VALUES (2, 4, 1, 0, '2006-12-06 11:21:28', 0x3132372e302e302e313a4e554c4c);
INSERT INTO `aevent_log` VALUES (3, 4, 1, 0, '2006-12-07 09:32:52', 0x3132372e302e302e313a4e554c4c);
INSERT INTO `aevent_log` VALUES (4, 4, 1, 0, '2006-12-07 20:32:35', 0x3132372e302e302e313a4e554c4c);

-- --------------------------------------------------------

-- 
-- Структура таблицы `asession`
-- 

DROP TABLE IF EXISTS `asession`;
CREATE TABLE `asession` (
  `asession_id` int(10) unsigned NOT NULL auto_increment,
  `auser_id` int(10) unsigned NOT NULL default '0',
  `sid` varchar(64) collate utf8_bin NOT NULL default '',
  `auid` varchar(64) collate utf8_bin NOT NULL default '',
  `dt_access` datetime NOT NULL default '0000-00-00 00:00:00',
  `dt_logon` datetime default NULL,
  `dt_logout` datetime default NULL,
  PRIMARY KEY  (`asession_id`),
  KEY `ix_asession_0` (`auser_id`),
  KEY `ix_asession_1` (`auid`,`dt_access`),
  KEY `ix_asession_2` (`dt_access`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=6 ;

-- 
-- Дамп данных таблицы `asession`
-- 

INSERT INTO `asession` VALUES (1, 0, 0x3132372e302e302e313a4e554c4c3d6263626562363562393939646439623365313439353430333532646137623435, 0x3132372e302e302e313a4e554c4c3d3633643762393830616665306663363065326265383931396565643032643332, '2006-12-03 00:47:40', NULL, NULL);
INSERT INTO `asession` VALUES (4, 0, 0x3132372e302e302e313a4e554c4c3d6531346463346435316261343334366231636535666166343866323362656266, 0x3132372e302e302e313a4e554c4c3d6135633864323564633164363137366132633434353866373235656131656332, '2006-12-07 17:32:25', NULL, NULL);
INSERT INTO `asession` VALUES (3, 4, 0x3132372e302e302e313a4e554c4c3d3965363339383131383534623566363034613865386532306336323762346231, 0x3132372e302e302e313a4e554c4c3d3065653065366335393433353639613334343239653331356437356562623063, '2006-12-07 18:53:16', '2006-12-07 09:32:52', '2006-10-23 11:26:01');
INSERT INTO `asession` VALUES (5, 4, 0x3132372e302e302e313a4e554c4c3d3965613235313035613961623130396133316464303837356632343932626335, 0x3132372e302e302e313a4e554c4c3d3239303937393433346633666531636236646439393166653166323266366530, '2006-12-07 20:32:35', '2006-12-07 20:32:35', '2006-10-23 11:26:01');

-- --------------------------------------------------------

-- 
-- Структура таблицы `auser`
-- 

DROP TABLE IF EXISTS `auser`;
CREATE TABLE `auser` (
  `auser_id` int(10) unsigned NOT NULL auto_increment,
  `auser_type_id` tinyint(3) unsigned NOT NULL default '0',
  `rights` int(10) unsigned NOT NULL default '0',
  `name` varchar(127) collate utf8_bin NOT NULL default '',
  `description` text collate utf8_bin,
  `email` varchar(63) collate utf8_bin NOT NULL default '',
  `passwd` varchar(63) collate utf8_bin NOT NULL default '',
  `new_passwd` varchar(63) collate utf8_bin default NULL,
  `dt_register` datetime NOT NULL default '0000-00-00 00:00:00',
  `dt_logon` datetime default NULL,
  `dt_logout` datetime default NULL,
  `is_published` tinyint(3) unsigned NOT NULL default '1',
  `is_default` tinyint(3) unsigned NOT NULL default '0',
  `connections_limit` tinyint(3) unsigned NOT NULL default '1',
  `event_type` mediumint(8) unsigned NOT NULL default '0',
  `fio` varchar(100) collate utf8_bin NOT NULL default '',
  `www` varchar(255) collate utf8_bin NOT NULL default '',
  `adress` text collate utf8_bin NOT NULL,
  `dt_birth` date NOT NULL default '0000-00-00',
  `work_place` varchar(100) collate utf8_bin NOT NULL default '',
  `work_position` varchar(100) collate utf8_bin NOT NULL default '',
  `telefon` bigint(20) NOT NULL default '0',
  PRIMARY KEY  (`auser_id`),
  UNIQUE KEY `auser_type_id` (`auser_type_id`,`name`),
  KEY `ix_auser_0` (`auser_type_id`,`is_published`,`dt_logon`),
  KEY `ix_auser_1` (`dt_register`),
  KEY `ix_auser_2` (`auser_type_id`,`name`,`passwd`),
  KEY `ix_auser_3` (`auser_type_id`,`email`,`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=14 ;

-- 
-- Дамп данных таблицы `auser`
-- 

INSERT INTO `auser` VALUES (1, 2, 143, 0x4f776e6572, 0xd0a1d0bed0b7d0b4d0b0d182d0b5d0bbd18c20d0bed0b1d18ad0b5d0bad182d0b0, 0x6f776e6572, 0x6f6e776e6572, NULL, '2006-05-18 10:39:47', NULL, NULL, 1, 0, 1, 0, '', '', '', '0000-00-00', '', '', 0);
INSERT INTO `auser` VALUES (2, 1, 143, 0x41646d696e73, 0xd093d180d183d0bfd0bfd0b020d0b0d0b4d0bcd0b8d0bdd0b8d181d182d180d0b0d182d0bed180d0bed0b220d181d0b8d181d182d0b5d0bcd18b, 0x67726f7570, 0x67726f7570, NULL, '2006-05-18 10:39:47', NULL, NULL, 1, 0, 1, 0, '', '', '', '0000-00-00', '', '', 0);
INSERT INTO `auser` VALUES (3, 0, 16777215, 0x61646d696e, '', 0x6d697368614064657369676e2e7275, 0x2461707231243376772f454f42332475596f78745a55376f4c69536f56645855454b387331, NULL, '2006-05-18 10:39:47', '2006-12-05 12:18:35', NULL, 1, 0, 1, 0, '', '', '', '0000-00-00', '', '', 0);
INSERT INTO `auser` VALUES (4, 0, 16777215, 0x6b6c656e, '', 0x6b6c656e2e636f6d406d61696c2e7275, 0x246170723124572f5478654d654c24716f6a754831743063456342577939596f435668362e, NULL, '2006-05-18 11:05:02', '2006-12-07 20:32:35', '2006-10-23 11:26:01', 1, 0, 1, 147, 0xd09ad0bbd0b5d0bdd0bed0b220d09ad0b8d180d0b8d0bbd0bb20d0add0b4d183d0b0d180d0b4d0bed0b2d0b8d187, '', '', '1979-12-31', 0xd09dd0b520d183d0bad0b0d0b7d0b0d0bd, 0xd0a1d0b0d0bcd18bd0b920d0b3d0bbd0b0d0b2d0bdd18bd0b9, 89630210959);
INSERT INTO `auser` VALUES (11, 0, 1, 0x74657374, 0xd0a2d0b5d181d182d0bed0b2d18bd0b920d0bfd0bed0bbd18cd0b7d0bed0b2d0b0d182d0b5d0bbd18c, 0x7465737440746573742e7275, 0x2461707231244731364f6d2f7a50246d4e4a346541456f74626c7256317969767253715330, NULL, '2006-11-08 00:31:52', NULL, NULL, 1, 0, 1, 0, '', '', '', '0000-00-00', '', '', 0);
INSERT INTO `auser` VALUES (5, 0, 143, 0xd09cd183d0b7d0b020d092d0bbd0b0d0b4d0b8d0bcd0b8d180d0bed0b2d0bdd0b0, 0xd0a1d0b8d180d0bed182d0b0, 0x6d757361406d61696c2e7275, 0x2461707231244a664f3669466e3824543352656f785a5a4b57777a314a467832503732512e, NULL, '2006-10-15 12:04:48', '2006-10-15 12:30:40', NULL, 1, 0, 1, 147, '', '', '', '0000-00-00', 0xd09dd0b520d183d0bad0b0d0b7d0b0d0bd, '', 0);
INSERT INTO `auser` VALUES (10, 1, 1, 0x54657374657273, 0xd093d180d183d0bfd0bfd0b020d182d0b5d181d182d0bed0b2d18bd18520d0bfd0bed0bbd18cd0b7d0bed0b2d0b0d182d0b5d0bbd0b5d0b9, 0x67726f7570, '', NULL, '2006-11-08 00:14:38', NULL, NULL, 1, 0, 1, 0, '', '', '', '0000-00-00', '', '', 0);

-- --------------------------------------------------------

-- 
-- Структура таблицы `auser_to_auser`
-- 

DROP TABLE IF EXISTS `auser_to_auser`;
CREATE TABLE `auser_to_auser` (
  `auser_id` int(10) unsigned NOT NULL default '0',
  `parent_id` int(10) unsigned NOT NULL default '0',
  `rights` int(10) unsigned NOT NULL default '0',
  UNIQUE KEY `ix_auser_to_auser_0` (`auser_id`,`parent_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- 
-- Дамп данных таблицы `auser_to_auser`
-- 

INSERT INTO `auser_to_auser` VALUES (3, 2, 0);
INSERT INTO `auser_to_auser` VALUES (5, 2, 0);
INSERT INTO `auser_to_auser` VALUES (4, 2, 0);
INSERT INTO `auser_to_auser` VALUES (11, 10, 0);
INSERT INTO `auser_to_auser` VALUES (12, 13, 0);

-- --------------------------------------------------------

-- 
-- Структура таблицы `m_b_article`
-- 

DROP TABLE IF EXISTS `m_b_article`;
CREATE TABLE `m_b_article` (
  `article_type_id` int(11) NOT NULL default '0',
  `article_id` int(11) NOT NULL auto_increment,
  `title` varchar(255) collate utf8_bin default NULL,
  `lead` text collate utf8_bin NOT NULL,
  `uri` varchar(255) collate utf8_bin default NULL,
  `url` varchar(255) collate utf8_bin default NULL,
  `is_not_empty` tinyint(4) default '0',
  `body` text collate utf8_bin,
  `is_published` tinyint(4) default '0',
  `dt` datetime NOT NULL default '0000-00-00 00:00:00',
  `dt_published` datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`article_type_id`,`article_id`),
  KEY `ix_m_article_0` (`article_type_id`,`is_published`,`dt_published`,`dt`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=1 ;

-- 
-- Дамп данных таблицы `m_b_article`
-- 

INSERT INTO `m_b_article` VALUES (1, 1, 0xd0a2d0b5d181d182d0bed0b2d0b0d18f20d0bdd0bed0b2d0bed181d182d18c, 0x3c703ed09fd180d0bed181d182d0be20d0bdd0bed0b2d0bed181d182d18c20d0b4d0bbd18f20d0bfd180d0bed0b2d0b5d180d0bad0b820d0b4d0b2d0b8d0b6d0bad0b02e20d09fd180d0bed181d182d0be20d0bdd0bed0b2d0bed181d182d18c20d0b4d0bbd18f20d0bfd180d0bed0b2d0b5d180d0bad0b820d0b4d0b2d0b8d0b6d0bad0b02e20d09fd180d0bed181d182d0be20d0bdd0bed0b2d0bed181d182d18c20d0b4d0bbd18f20d0bfd180d0bed0b2d0b5d180d0bad0b820d0b4d0b2d0b8d0b6d0bad0b02e20d09fd180d0bed181d182d0be20d0bdd0bed0b2d0bed181d182d18c20d0b4d0bbd18f20d0bfd180d0bed0b2d0b5d180d0bad0b820d0b4d0b2d0b8d0b6d0bad0b02e20d09fd180d0bed181d182d0be20d0bdd0bed0b2d0bed181d182d18c20d0b4d0bbd18f20d0bfd180d0bed0b2d0b5d180d0bad0b820d0b4d0b2d0b8d0b6d0bad0b02e20d09fd180d0bed181d182d0be20d0bdd0bed0b2d0bed181d182d18c20d0b4d0bbd18f20d0bfd180d0bed0b2d0b5d180d0bad0b820d0b4d0b2d0b8d0b6d0bad0b02e20d09fd180d0bed181d182d0be20d0bdd0bed0b2d0bed181d182d18c20d0b4d0bbd18f20d0bfd180d0bed0b2d0b5d180d0bad0b820d0b4d0b2d0b8d0b6d0bad0b02e20d09fd180d0bed181d182d0be20d0bdd0bed0b2d0bed181d182d18c20d0b4d0bbd18f20d0bfd180d0bed0b2d0b5d180d0bad0b820d0b4d0b2d0b8d0b6d0bad0b02e20d09fd180d0bed181d182d0be20d0bdd0bed0b2d0bed181d182d18c20d0b4d0bbd18f20d0bfd180d0bed0b2d0b5d180d0bad0b820d0b4d0b2d0b8d0b6d0bad0b02e20d09fd180d0bed181d182d0be20d0bdd0bed0b2d0bed181d182d18c20d0b4d0bbd18f20d0bfd180d0bed0b2d0b5d180d0bad0b820d0b4d0b2d0b8d0b6d0bad0b02e20d09fd180d0bed181d182d0be20d0bdd0bed0b2d0bed181d182d18c20d0b4d0bbd18f20d0bfd180d0bed0b2d0b5d180d0bad0b820d0b4d0b2d0b8d0b6d0bad0b02e20d09fd180d0bed181d182d0be20d0bdd0bed0b2d0bed181d182d18c20d0b4d0bbd18f20d0bfd180d0bed0b2d0b5d180d0bad0b820d0b4d0b2d0b8d0b6d0bad0b02e20d09fd180d0bed181d182d0be20d0bdd0bed0b2d0bed181d182d18c20d0b4d0bbd18f20d0bfd180d0bed0b2d0b5d180d0bad0b820d0b4d0b2d0b8d0b6d0bad0b02e20d09fd180d0bed181d182d0be20d0bdd0bed0b2d0bed181d182d18c20d0b4d0bbd18f20d0bfd180d0bed0b2d0b5d180d0bad0b820d0b4d0b2d0b8d0b6d0bad0b02e203c2f703e0d0a3c703ed09fd180d0bed181d182d0be20d0bdd0bed0b2d0bed181d182d18c20d0b4d0bbd18f20d0bfd180d0bed0b2d0b5d180d0bad0b820d0b4d0b2d0b8d0b6d0bad0b02e20d09fd180d0bed181d182d0be20d0bdd0bed0b2d0bed181d182d18c20d0b4d0bbd18f20d0bfd180d0bed0b2d0b5d180d0bad0b820d0b4d0b2d0b8d0b6d0bad0b02e20d09fd180d0bed181d182d0be20d0bdd0bed0b2d0bed181d182d18c20d0b4d0bbd18f20d0bfd180d0bed0b2d0b5d180d0bad0b820d0b4d0b2d0b8d0b6d0bad0b02e203c2f703e, NULL, NULL, 1, 0xd097d0b4d0b5d181d18c20d182d0b5d0bad181d18220d182d0b5d181d182d0bed0b2d0bed0b920d0bdd0bed0b2d0bed181d182d0b8, 1, '2006-10-10 00:00:00', '2006-10-10 00:00:00');
INSERT INTO `m_b_article` VALUES (1, 2, 0xd09fd180d0bed0b2d0b5d180d0bad0b0, 0xd0b1d0bbd0b020d0b1d0bbd0b0, NULL, NULL, 1, 0xd0b0d0bfd0bed180d0b0d0bfd0be, 0, '2006-10-12 00:00:00', '2006-10-12 00:00:00');
INSERT INTO `m_b_article` VALUES (1, 3, 0xd0bcd0b8d182d0b0d0bfd0bed180, 0xd0b0d0bfd180d0b0d0bfd180d0b0d0bfd180d0b0, NULL, NULL, 1, 0xd0b0d0bfd180d0b0d0bfd180d0b0d0bfd180, 0, '2006-10-09 00:00:00', '2006-10-08 00:00:00');

-- --------------------------------------------------------

-- 
-- Структура таблицы `m_b_article_type`
-- 

DROP TABLE IF EXISTS `m_b_article_type`;
CREATE TABLE `m_b_article_type` (
  `article_type_id` int(11) NOT NULL auto_increment,
  `path` varchar(255) collate utf8_bin NOT NULL default '',
  `name` varchar(255) collate utf8_bin NOT NULL default '',
  `irf` int(9) default NULL,
  PRIMARY KEY  (`article_type_id`),
  UNIQUE KEY `path` (`path`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=2 ;

-- 
-- Дамп данных таблицы `m_b_article_type`
-- 

INSERT INTO `m_b_article_type` VALUES (1, 0x2f, 0xd09dd0bed0b2d0bed181d182d0b820d0bdd0b020d0b3d0bbd0b0d0b2d0bdd0bed0b9, 255);

-- --------------------------------------------------------

-- 
-- Структура таблицы `m_block`
-- 

DROP TABLE IF EXISTS `m_block`;
CREATE TABLE `m_block` (
  `block_id` int(11) NOT NULL auto_increment,
  `data_process_id` tinyint(4) NOT NULL default '0',
  `name` varchar(40) collate utf8_bin NOT NULL default '',
  `data_type_id` tinyint(4) NOT NULL default '0',
  `is_not_empty` char(1) collate utf8_bin NOT NULL default '0',
  `is_published` char(1) collate utf8_bin NOT NULL default '0',
  `is_hide_published` char(1) collate utf8_bin NOT NULL default '0',
  `is_shared` char(1) collate utf8_bin NOT NULL default '0',
  `is_parsed_manual` char(1) collate utf8_bin NOT NULL default '0',
  `dt_update` date NOT NULL default '0000-00-00',
  `attr` text collate utf8_bin NOT NULL,
  `description` varchar(255) collate utf8_bin NOT NULL default '',
  `data` text collate utf8_bin NOT NULL,
  PRIMARY KEY  (`block_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=231 ;

-- 
-- Дамп данных таблицы `m_block`
-- 

INSERT INTO `m_block` VALUES (1, 3, 0x736974653a617574683a6c6f67696e, 5, 0x31, 0x31, 0x30, 0x30, 0x30, '2006-11-15', '', 0xd098d0bdd184d0bed180d0bcd0b0d186d0b8d18f20d0be20d0b7d0b0d0bbd0bed0b3d0b8d0bdd0b5d0bdd0bdd0bed0bc20d0bfd0bed0bbd18cd0b7d0bed0b2d0b0d182d0b5d0bbd0b52c20d0b2d18bd0b2d0bed0b420d0bbd0bed0b3d0b8d0bdd0b0, 0x3c6e616d653ed09fd0bed0bbd18cd0b7d0bed0b2d0b0d182d0b5d0bbd18c3c2f6e616d653e);
INSERT INTO `m_block` VALUES (2, 0, 0x736974653a64657369676e3a746f706d656e75, 3, 0x31, 0x31, 0x30, 0x31, 0x30, '2006-10-17', 0x5374796c655b305d, 0xd092d18bd0b2d0bed0b4d0b8d18220d0bed181d0bdd0bed0b2d0bdd0bed0b520d0bcd0b5d0bdd18e, 0x3c6d656e753e3c2f6d656e753e0d0a0d0a);
INSERT INTO `m_block` VALUES (3, 0, 0x736974653a6d6170, 3, 0x31, 0x31, 0x30, 0x31, 0x30, '2006-11-15', 0x20, 0xd09ad0b0d180d182d0b020d181d0b0d0b9d182d0b0, 0x3c626c6f636b5f636f6e74656e743e3c6d61703e3c2f6d61703e3c2f626c6f636b5f636f6e74656e743e2020);
INSERT INTO `m_block` VALUES (4, 0, 0x736974653a6f7074696f6e, 3, 0x31, 0x31, '', 0x31, '', '2006-10-05', 0x5374796c655b305d43616368655b3330305d, 0xd09fd0b0d0bdd0b5d0bbd18c20d183d0bfd180d0b0d0b2d0bbd0b5d0bdd0b8d18f, 0x3c626c6f636b5f636f6e74656e743e0d0a3c627574746f6e733e0d0a3c627574746f6e20696d6167653d2232345f786d6c2e676966222020206e616d653d22786d6c22202020616c743d22d092d18bd0b2d0b5d181d182d0b820786d6c20d181d182d180d0b0d0bdd0b8d186d18b22206f6e436c69636b3d2277696e646f772e6f70656e28277b2473797374656d2f7061727365722f726571756573742f7572697d3f6d6f64653d786d6c272c2027786d6c272922202f3e0d0a3c627574746f6e20696d6167653d2232345f64656275672e676966222020206e616d653d22646562756722202020616c743d22d0a0d0b5d0b6d0b8d0bc20d0bed182d0bbd0b0d0b4d0bad0b820d181d182d180d0b0d0bdd0b8d186d18b22206f6e436c69636b3d2277696e646f772e6f70656e28277b2473797374656d2f7061727365722f726571756573742f7572697d3f6d6f64653d6465627567272c20276465627567272922202f3e0d0a3c627574746f6e20696d6167653d2232345f6e6f63616368652e676966222020206e616d653d226e6f636163686522202020616c743d22d092d18bd0b2d0b5d181d182d0b820d0b1d0b5d0b720d0bad18dd188d0b022206f6e436c69636b3d2277696e646f772e6f70656e28277b2473797374656d2f7061727365722f726571756573742f7572697d3f6d6f64653d6e6f6361636865272c20276e6f6361636865272922202f3e0d0a3c627574746f6e20696d6167653d2232345f6e6364656275672e676966222020206e616d653d226e63646562756722202020616c743d22d09ed182d0bbd0b0d0b4d0bad0b020d0b1d0b5d0b720d0bad18dd188d0b022206f6e436c69636b3d2277696e646f772e6f70656e28277b2473797374656d2f7061727365722f726571756573742f7572697d3f6d6f64653d6e636465627567272c20276e6f6361636865272922202f3e0d0a3c2f627574746f6e733e0d0a3c2f626c6f636b5f636f6e74656e743e);
INSERT INTO `m_block` VALUES (228, 0, 0x6f626a6563743a64657369676e3a636f6465, 9, 0x30, 0x31, 0x30, 0x30, 0x30, '2006-11-05', 0x5374796c655b305d, 0xd09fd0bed0b4d0b3d180d183d0b7d0bad0b0206a61766120d181d0bad180d0b8d0bfd182d0bed0b2, 0x3c6a735f686561643e202428646f63756d656e74292e72656164792866756e6374696f6e2829207b20242827236c6f6164696e67416a617827292e6869646528293b207d293b203c2f6a735f686561643e);
INSERT INTO `m_block` VALUES (5, 0, 0x736974653a64657369676e3a626164676573, 4, 0x31, 0x31, 0x30, 0x31, 0x30, '2006-10-22', 0x5374796c655b305d, 0xd091d0bbd0bed0ba20d0bad0bdd0bed0bfd0bed0ba, 0x3c6261646765733e0d0a3c62722f3e3c62722f3e0d0a202020203c6c6920636c6173733d22627574746f6e73223e3c6120687265663d22687474703a2f2f7777772e72752e656f6d792e6e65742f223e3c696d67207372633d22687474703a2f2f7777772e72752e656f6d792e6e65742f656f6d792e6e65742e6769662220626f726465723d22302220616c743d22454f4d592e4e4554222f3e3c2f613e3c2f6c693e0d0a202020203c6c6920636c6173733d22627574746f6e73223e3c6120687265663d22687474703a2f2f6b6c656e2e7a6f78742e6e65742f223e3c696d67207372633d222f696d616765732f6d6f7573655f38307831352e6a70672220626f726465723d22302220616c743d22506f7765726564206279204d6f75736520434d53222f3e3c2f613e3c2f6c693e0d0a202020203c6c6920636c6173733d22627574746f6e73223e3c6120687265663d22687474703a2f2f7777772e7061727365722e72752f223e3c696d67207372633d222f696d616765732f6261646765732f7061727365722e6769662220626f726465723d22302220616c743d22506f776572656420627920506172736572222f3e3c2f613e3c2f6c693e0d0a202020203c6c6920636c6173733d22627574746f6e73223e3c6120687265663d22687474703a2f2f7777772e6170616368652e6f72672f223e3c696d67207372633d222f696d616765732f6261646765732f6170616368652e706e672220626f726465723d22302220616c743d22506f776572656420627920417061636865222f3e3c2f613e3c2f6c693e0d0a202020203c6c6920636c6173733d22627574746f6e73223e3c6120687265663d22687474703a2f2f7777772e6d7973716c2e6f72672f223e3c696d67207372633d222f696d616765732f6261646765732f6d7973716c2e706e672220626f726465723d22302220616c743d22506f7765726564206279204d7953514c222f3e3c2f613e3c2f6c693e0d0a3c2f6261646765733e);
INSERT INTO `m_block` VALUES (6, 11, 0x736974653a7265676973746572, 5, 0x30, 0x31, '', 0x31, 0x30, '2006-09-30', '', 0xd0a0d0b5d0b3d0b8d181d182d180d0b0d186d0b8d18f20d0b820d0b8d0b7d0bcd0b5d0bdd0b5d0bdd0b8d0b520d0bbd0b8d187d0bdd18bd18520d0b4d0b0d0bdd0bdd18bd18520d0bfd0bed0bbd18cd0b7d0bed0b2d0b0d182d0b5d0bbd0b5d0b9, '');
INSERT INTO `m_block` VALUES (12, 1, 0x61646d696e3a6f626a6563742e74726565, 1, 0x31, 0x31, 0x30, 0x31, 0x30, '2006-10-06', 0x5374796c655b305d, 0xd0a3d0bfd180d0b0d0b2d0bbd0b5d0bdd0b8d0b520d0bed0b1d18ad0b5d0bad182d0b0d0bcd0b8, 0x3c626c6f636b5f636f6e74656e743e0d0a3c6a715f6f626a6563743e0d0a20203c6272616e6368652069643d223022206e616d653d22d09ad0bed180d0bdd0b5d0b2d0bed0b520d0bfd180d0bed181d182d180d0b0d0bdd181d182d0b2d0be2220706172656e745f69643d223022207468726561645f69643d22302220706174683d22223e0d0a202020203c73797374656d3a6d6574686f64206e616d653d2274726565223e686173685f6e616d655b4f424a454354535f484153485f545245455d7468726561645f69645b305d3c2f73797374656d3a6d6574686f643e0d0a20203c2f6272616e6368653e0d0a3c2f6a715f6f626a6563743e0d0a3c2f626c6f636b5f636f6e74656e743e0d0a);
INSERT INTO `m_block` VALUES (224, 32, 0x736974653a636f6e74656e743a61727469636c6573, 7, 0x31, 0x31, 0x30, 0x31, 0x30, '2006-10-22', 0x5374796c655b305d, 0xd0a3d0bfd180d0b0d0b2d0bbd0b5d0bdd0b8d0b520d181d182d0b0d182d18cd18fd0bcd0b82c20d0bdd0bed0b2d0bed181d182d0b82c20d0b0d0bdd0bed0bdd181d0b0d0bcd0b820d0b820d182d0bf2e, 0x3c626c6f636b5f636f6e74656e743e0d0a7b2473797374656d2f7061727365722f666f726d2f796561727d0d0a7b2473797374656d2f7061727365722f666f726d2f6d6f6e74687d0d0ad0bfd180d0bed0b2d0b5d180d0bad0b00d0a3c2f626c6f636b5f636f6e74656e743e);
INSERT INTO `m_block` VALUES (31, 4, 0x736974653a636f6e74656e743a61666f72697a6d, 7, 0x30, 0x31, 0x30, 0x31, 0x30, '2006-10-17', 0x5374796c655b305d, 0xd092d18bd0b2d0bed0b4d0b8d18220d181d0bbd183d187d0b0d0b9d0bdd18bd0b920d0b0d184d0bed180d0b8d0b7d0bc, '');
INSERT INTO `m_block` VALUES (208, 13, 0x736974653a636f6e74656e743a77656174686572, 7, 0x31, 0x31, 0x30, 0x31, 0x30, '2006-10-19', '', 0x74657374, 0x74657374);
INSERT INTO `m_block` VALUES (223, 0, 0x6f626a6563743a6572726f72, 3, 0x31, 0x31, 0x30, 0x30, 0x30, '2006-11-15', '', 0xd091d0bbd0bed0ba20d0bed0b1d180d0b0d0b1d0b0d182d18bd0b2d0b0d18ed189d0b8d0b920d0b8d0bdd184d0bed180d0bcd0b0d186d0b8d18e20d0bed0b120d0bed188d0b8d0b1d0bad0b0d18520d181d0b8d181d182d0b5d0bcd18b, 0x3c626c6f636b5f636f6e74656e743e0d0a3c68333ed0a2d0b8d0bf20d0bed188d0b8d0b1d0bad0b83a203c2f68333e0d0a3c62722f3e0d0a3c703e200d0a3c73797374656d3a6d6574686f64206e616d653d2273656c656374223e6e616d655b7b2473797374656d2f7061727365722f666f726d2f6572726f727d5d76616c75655b636d732e3430345d747275655bd097d0b0d0bfd180d0b0d188d0b8d0b2d0b0d0b5d0bcd0b0d18f20d0b2d0b0d0bcd0b820d181d182d180d0b0d0bdd0b8d186d0b020277b2473797374656d2f7061727365722f666f726d2f75726c7d2720d0bdd0b5d0b4d0bed181d182d183d0bfd0bdd0b02c20d0bfd0bed0b6d0b0d0bbd183d0b9d181d182d0b020d0b2d0bed181d0bfd0bed0bbd18cd0b7d183d0b9d182d0b5d181d18c20d0bad0b0d180d182d0bed0b920d181d0b0d0b9d182d0b02e5d3c2f73797374656d3a6d6574686f643e0d0a3c73797374656d3a6d6574686f64206e616d653d2273656c656374223e6e616d655b7b2473797374656d2f7061727365722f666f726d2f6572726f727d5d76616c75655b636d732e3430335d747275655bd0a320d0b2d0b0d18120d0bdd0b5d0b4d0bed181d182d0b0d182d0bed187d0bdd0be20d0bfd180d0b0d0b220d0b4d0bbd18f20d0b7d0b0d0bfd180d0b0d188d0b8d0b2d0b0d0b5d0bcd0bed0b3d0be20d0b2d0b0d0bcd0b820d180d0b0d0b7d0b4d0b5d0bbd0b020277b2473797374656d2f7061727365722f666f726d2f75726c7d272c20d0bfd0bed0b6d0b0d0bbd183d0b9d181d182d0b020d0b2d0bed181d0bfd0bed0bbd18cd0b7d183d0b9d182d0b5d181d18c20d0bad0b0d180d182d0bed0b920d181d0b0d0b9d182d0b02e5d3c2f73797374656d3a6d6574686f643e0d0a3c2f703e0d0a3c2f626c6f636b5f636f6e74656e743e);
INSERT INTO `m_block` VALUES (227, 0, 0x6f626a6563743a676c6f62616c3a64657369676e3a636f6465, 4, 0x31, 0x31, 0x30, 0x31, 0x30, '2006-10-22', 0x5374796c655b305d, 0xd0b1d0bbd0bed0ba20d0bfd0bed0b4d0bad0bbd18ed187d0b0d0b5d182206a61766120d181d0bad180d0b8d0bfd182d18b20d181d0b0d0b9d182d0b0, 0x3c6a7320736f757263653d222f6a732f6a712f6a712e6a73222f3e0d0a3c6a7320736f757263653d222f6a732f6a712f697574696c2e6a73222f3e0d0a3c6a7320736f757263653d222f6a732f6a712f6966782e6a73222f3e0d0a3c6a7320736f757263653d222f6a732f6a712f696678736c6964652e6a73222f3e0d0a3c6a7320736f757263653d222f6a732f6a712f6966787472616e736665722e6a73222f3e0d0a3c6a7320736f757263653d222f6a732f6a712f69667870756c736174652e6a73222f3e0d0a3c6a7320736f757263653d222f6a732f6a712f69667864726f702e6a73222f3e0d0a3c6a7320736f757263653d222f6a732f6a712f6966787363726f6c6c746f2e6a73222f3e0d0a3c6a7320736f757263653d222f6a732f6a712f6966787363616c652e6a73222f3e0d0a3c63737320736f757263653d222f7468656d65732f6d6f7573652f6373732f6d6f64756c65732e637373222f3e);
INSERT INTO `m_block` VALUES (225, 0, 0x736974653a64657369676e3a6c6566746d656e75, 3, 0x31, 0x31, 0x30, 0x31, 0x30, '2006-10-20', 0x5374796c655b305d, 0xd09bd0b5d0b2d0bed0b520d0b8d0bbd0b820d0bfd180d0b0d0b2d0bed0b520d0bcd0b5d0bdd18e20d181d0b0d0b9d182d0b02c20d184d0b0d0bad182d0b8d187d0b5d181d0bad0b820d0bad0b0d180d182d0b0, 0x3c626c6f636b5f636f6e74656e743e0d0a3c68323ed09cd0b5d0bdd18e3c2f68323e0d0a3c736964656d656e752f3e0d0a3c2f626c6f636b5f636f6e74656e743e);
INSERT INTO `m_block` VALUES (226, 31, 0x736974653a636f6e74656e743a6e6577733a63616c656e646172, 7, 0x31, 0x31, 0x30, 0x31, 0x30, '2006-10-20', '', 0xd092d18bd0b2d0bed0b4d0b8d18220d0bad0b0d0bbd0b5d0bdd0b4d0b0d180d18c20d0bdd0bed0b2d0bed181d182d0b5d0b92c20d181d182d0b0d182d0b5d0b920d0b820d182d0bf2e, 0x3c6e616d653ed09ad0b0d0bbd0b5d0bdd0b4d0b0d180d18c3c2f6e616d653e);
INSERT INTO `m_block` VALUES (229, 33, 0x6f626a6563743a61646d696e3a65646974, 1, 0x31, 0x31, 0x30, 0x31, 0x30, '2006-10-24', 0x5374796c655b305d, 0xd09dd0bed0b2d18bd0b920d0b2d0b0d180d0b8d0b0d0bdd18220d0b0d0b4d0bcd0b8d0bdd0bad0b8, '');
INSERT INTO `m_block` VALUES (230, 0, 0x6f626a6563743a61646d696e3a636f6465, 0, 0x31, 0x31, 0x30, 0x31, 0x30, '2006-10-25', 0x5374796c655b305d, '', 0x3c6a7320736f757263653d222f7468656d65732f6d6f7573652f6a732f7461626c652e6a7322202f3e0d0a3c6a7320736f757263653d222f7468656d65732f6d6f7573652f6a732f746162732e6a73222f3e0d0a3c6a7320736f757263653d222f7468656d65732f6d6f7573652f6a732f61646d696e2e6a7322202f3e0d0a3c63737320736f757263653d222f7468656d65732f6d6f7573652f6373732f7461626c652d6275696c6465722e637373222f3e0d0a3c63737320736f757263653d222f7468656d65732f6d6f7573652f6373732f666f726d2d6275696c6465722e637373222f3e0d0a3c6a735f686561643e0d0a7369746573203d20277b2473797374656d2f4f424a454354535f484153482f38302f66756c6c5f706174687d3f747970653d7369746573273b0d0a6f626a656374733d277b2473797374656d2f4f424a454354535f484153482f38302f66756c6c5f706174687d3f747970653d6f626a65637473273b0d0a626c6f636b733d277b2473797374656d2f4f424a454354535f484153482f38302f66756c6c5f706174687d3f747970653d626c6f636b73273b0d0a70726f636573733d277b2473797374656d2f4f424a454354535f484153482f38302f66756c6c5f706174687d3f747970653d70726f63657373273b0d0a3c2f6a735f686561643e0d0a3c626c6f636b5f636f6e74656e743e0d0a3c6469762069643d226c6f6164696e67416a6178223e3c6c693e3c696d67207372633d222f696d616765732f6c6f6164696e672e676966222f3e20d0b7d0b0d0b3d180d183d0b7d0bad0b0203c2f6c693e3c2f6469763e0d0a3c2f626c6f636b5f636f6e74656e743e);

-- --------------------------------------------------------

-- 
-- Структура таблицы `m_block_template`
-- 

DROP TABLE IF EXISTS `m_block_template`;
CREATE TABLE `m_block_template` (
  `m_block_template_id` int(11) NOT NULL auto_increment,
  `sort_order` tinyint(4) NOT NULL default '0',
  `data_type_id` tinyint(4) NOT NULL default '0',
  `data_process_id` tinyint(4) NOT NULL default '0',
  `is_published` char(1) collate utf8_bin NOT NULL default '',
  `is_hide_published` char(1) collate utf8_bin NOT NULL default '',
  `is_parsed_manual` char(1) collate utf8_bin NOT NULL default '',
  `name` varchar(255) collate utf8_bin NOT NULL default '',
  `description` text collate utf8_bin NOT NULL,
  `body` text collate utf8_bin NOT NULL,
  PRIMARY KEY  (`m_block_template_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=1 ;

-- 
-- Дамп данных таблицы `m_block_template`
-- 


-- --------------------------------------------------------

-- 
-- Структура таблицы `m_block_to_object`
-- 

DROP TABLE IF EXISTS `m_block_to_object`;
CREATE TABLE `m_block_to_object` (
  `block_to_object_id` int(11) NOT NULL auto_increment,
  `block_id` int(11) NOT NULL default '0',
  `object_id` int(11) NOT NULL default '0',
  `sort_order` int(4) NOT NULL default '1',
  `mode` int(4) NOT NULL default '1',
  PRIMARY KEY  (`block_to_object_id`),
  KEY `ix_object_id` (`object_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=780 ;

-- 
-- Дамп данных таблицы `m_block_to_object`
-- 

INSERT INTO `m_block_to_object` VALUES (762, 12, 79, 0, 2);
INSERT INTO `m_block_to_object` VALUES (750, 224, 1, 5, 1);
INSERT INTO `m_block_to_object` VALUES (723, 3, 3, 2, 1);
INSERT INTO `m_block_to_object` VALUES (761, 230, 79, 9, 1);
INSERT INTO `m_block_to_object` VALUES (760, 229, 80, 1, 1);
INSERT INTO `m_block_to_object` VALUES (751, 228, 1, 6, 1);
INSERT INTO `m_block_to_object` VALUES (759, 227, 29, 4, 1);
INSERT INTO `m_block_to_object` VALUES (749, 31, 1, 4, 1);
INSERT INTO `m_block_to_object` VALUES (748, 4, 1, 3, 1);
INSERT INTO `m_block_to_object` VALUES (719, 3, 2, 1, 1);
INSERT INTO `m_block_to_object` VALUES (722, 223, 3, 1, 1);
INSERT INTO `m_block_to_object` VALUES (721, 1, 4, 2, 2);
INSERT INTO `m_block_to_object` VALUES (720, 6, 4, 1, 1);
INSERT INTO `m_block_to_object` VALUES (747, 1, 1, 2, 2);
INSERT INTO `m_block_to_object` VALUES (758, 5, 29, 3, 2);
INSERT INTO `m_block_to_object` VALUES (746, 226, 1, 1, 2);
INSERT INTO `m_block_to_object` VALUES (697, 224, 28, 1, 1);
INSERT INTO `m_block_to_object` VALUES (699, 1, 27, 2, 2);
INSERT INTO `m_block_to_object` VALUES (698, 224, 27, 1, 1);
INSERT INTO `m_block_to_object` VALUES (757, 2, 29, 2, 1);
INSERT INTO `m_block_to_object` VALUES (756, 225, 29, 1, 2);
INSERT INTO `m_block_to_object` VALUES (778, 1, 85, 1, 1);
INSERT INTO `m_block_to_object` VALUES (779, 4, 85, 2, 1);

-- --------------------------------------------------------

-- 
-- Структура таблицы `m_data_process`
-- 

DROP TABLE IF EXISTS `m_data_process`;
CREATE TABLE `m_data_process` (
  `data_process_id` int(11) NOT NULL auto_increment,
  `sort_order` tinyint(4) NOT NULL default '0',
  `data_process_type_id` tinyint(4) NOT NULL default '0',
  `dt_update` date NOT NULL default '0000-00-00',
  `name` varchar(50) collate utf8_bin NOT NULL default '',
  `filename` varchar(255) collate utf8_bin NOT NULL default '',
  `description` varchar(255) collate utf8_bin NOT NULL default '',
  PRIMARY KEY  (`data_process_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=34 ;

-- 
-- Дамп данных таблицы `m_data_process`
-- 

INSERT INTO `m_data_process` VALUES (1, 2, 0, '2006-10-10', 0x6a715f61646d696e, 0x2f6d632f6c6f616465722e70, 0xd097d0b0d0b3d180d183d0b7d0bad0b020d0b8d0bdd184d0bed180d0bcd0b0d186d0b8d0b82c20d0bed182d0bad0bbd18ed187d0b5d0bdd0b8d0b520d0bad18dd188d0b0);
INSERT INTO `m_data_process` VALUES (3, 1, 0, '0000-00-00', 0x617574685f696e666f, 0x617574685f696e666f2e70, 0xd098d0bdd184d0bed180d0bcd0b0d186d0b8d18f20d0be20d0b7d0b0d0bbd0bed0b3d0b8d0bdd0b5d0bdd0bdd0bed0bc20d0bfd0bed0bbd18cd0b7d0bed0b2d0b0d182d0b5d0bbd0b52c20d0b2d18bd0b2d0bed0b420d0bbd0bed0b3d0b8d0bdd0b0);
INSERT INTO `m_data_process` VALUES (4, 3, 0, '0000-00-00', 0xd0b0d184d0bed180d0b8d0b7d0bcd18b, 0x7068796c6f736f7068792e70, 0xd092d18bd0b2d0bed0b4d0b8d18220d181d0bbd183d187d0b0d0b9d0bdd18bd0b920d0b0d184d0bed180d0b8d0b7d0bc);
INSERT INTO `m_data_process` VALUES (5, 4, 0, '2006-10-10', 0x656469746f72, 0x656469746f722e70, 0xd0a0d0b5d0b4d0b0d0bad182d0bed18020d0b4d0b0d0bdd0bdd18bd185);
INSERT INTO `m_data_process` VALUES (11, 9, 0, '2006-08-14', 0xd0a0d0b5d0b3d0b8d181d182d180d0b0d186d0b8d18f, 0x7265675f636f6e74726f6c2e70, 0xd0a0d0b5d0b3d0b8d181d182d180d0b0d186d0b8d18f20d0bfd0bed0bbd18cd0b7d0bed0b2d0b0d182d0b5d0bbd18f);
INSERT INTO `m_data_process` VALUES (13, 9, 0, '2006-08-14', 0xd0bfd0bed0b3d0bed0b4d0b0, 0x776561746865722e70, 0xd0bfd0bed0b3d0bed0b4d0b0);
INSERT INTO `m_data_process` VALUES (14, 9, 0, '2006-08-14', 0xd09dd0bed0b2d0bed181d182d0b8, 0x6e6577732e70, 0xd09dd0bed0b2d0bed181d182d0b820d0b820d181d0bbd183d0b6d0b5d0b1d0bdd18bd0b520d181d0bed0bed0b1d189d0b5d0bdd0b8d18f20d0bad0bed0bcd0bfd0b0d0bdd0b8d0b8);
INSERT INTO `m_data_process` VALUES (18, 9, 0, '2006-08-15', 0xd0bad0b0d180d182d0bed187d0bad0b020d181d0bed182d180d183d0b4d0bdd0b8d0bad0b0, 0x636172742e70, 0xd0bad0b0d180d182d0bed187d0bad0b020d181d0bed182d180d183d0b4d0bdd0b8d0bad0b0);
INSERT INTO `m_data_process` VALUES (20, 9, 0, '2006-08-16', 0xd09fd0bed0bbd18cd0b7d0bed0b2d0b0d182d0b5d0bbd0b8, 0x75736572732e70, 0xd0a3d0bfd180d0b0d0b2d0bbd0b5d0bdd0b8d0b520d0bfd0bed0bbd18cd0b7d0bed0b2d0b0d182d0b5d0bbd18fd0bcd0b8);
INSERT INTO `m_data_process` VALUES (21, 9, 0, '2006-08-16', 0xd0a0d0b5d0b4d0b0d0bad182d0b8d180d0bed0b2d0b0d0bdd0b8d0b520d0bfd0bed0bbd18cd0b7d0bed0b2d0b0d182d0b5d0bbd18f, 0x757365725f656469742e70, 0xd0a0d0b5d0b4d0b0d0bad182d0b8d180d0bed0b2d0b0d0bdd0b8d0b520d0bfd0bed0bbd18cd0b7d0bed0b2d0b0d182d0b5d0bbd18f);
INSERT INTO `m_data_process` VALUES (31, 5, 0, '2006-10-20', 0xd09ad0b0d0bbd0b5d0bdd0b4d0b0d180d18c20d181d182d0b0d182d0b5d0b9, 0x63616c656e6461722e70, 0xd092d18bd0b2d0bed0b4d0b8d18220d0bad0b0d0bbd0b5d0bdd0b4d0b0d180d18c20d181d182d0b0d182d0b5d0b920d0b7d0b0d0b4d0b0d0bdd0bdd0bed0b3d0be20d182d0b8d0bfd0b0);
INSERT INTO `m_data_process` VALUES (26, 9, 0, '2006-09-30', 0xd09ad0bdd0bed0bfd0bed187d0bad0b8, 0x627574746f6e73, 0xd091d0bbd0bed0ba20d0bad0bdd0bed0bfd0bed0ba);
INSERT INTO `m_data_process` VALUES (28, 9, 0, '2006-10-01', 0xd0a0d0b5d0b4d0b0d0bad182d0bed180, 0x656469746f722e70, 0xd09ed0b1d180d0b0d0b1d0bed182d0bad0b020d0b4d0b0d0bdd0bdd18bd185);
INSERT INTO `m_data_process` VALUES (32, 6, 0, '2006-10-20', 0xd092d18bd0b2d0bed0b420d181d182d0b0d182d0b5d0b9, 0x61727469636c652e70, 0xd092d18bd0b2d0bed0b4d0b8d18220d0bed0bfd180d0b5d0b4d0b5d0bbd0b5d0bdd0bdd18bd0b520d182d0b8d0bfd18b20d181d182d0b0d182d0b5d0b920d0b220d0b7d0b0d0b2d0b8d181d0b8d0bcd0bed181d182d0b820d0bed18220d0b7d0b0d0b4d0b0d0bdd0bdd0bed0b3d0be20d0bfd183d182d0b8);
INSERT INTO `m_data_process` VALUES (33, 11, 0, '2006-11-06', 0xd090d0b4d0bcd0b8d0bdd0bad0b0, 0x2f6d632f636f6e74726f6c2e70, 0xd09ed0b1d180d0b0d0b1d0bed182d187d0b8d0ba20d0b0d0b4d0bcd0b8d0bdd0bad0b8);

-- --------------------------------------------------------

-- 
-- Структура таблицы `m_data_process_type`
-- 

DROP TABLE IF EXISTS `m_data_process_type`;
CREATE TABLE `m_data_process_type` (
  `data_process_type_id` int(11) NOT NULL auto_increment,
  `sort_order` int(11) NOT NULL default '0',
  `name` varchar(255) collate utf8_bin NOT NULL default '',
  PRIMARY KEY  (`data_process_type_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=5 ;

-- 
-- Дамп данных таблицы `m_data_process_type`
-- 

INSERT INTO `m_data_process_type` VALUES (1, 1, 0xd09dd0b5d0bed0bfd180d0b5d0b4d0b5d0bbd0b5d0bdd0bdd18bd0b920d182d0b8d0bf);
INSERT INTO `m_data_process_type` VALUES (2, 2, 0xd090d0b4d0bcd0b8d0bdd0bad0b0202d20d0bed0b1d18ad0b5d0bad182d18b);
INSERT INTO `m_data_process_type` VALUES (3, 3, 0xd090d0b4d0bcd0b8d0bdd0bad0b0202d20d0b1d0bbd0bed0bad0b8);
INSERT INTO `m_data_process_type` VALUES (4, 4, 0xd090d0b4d0bcd0b8d0bdd0bad0b0202d20d0bed0b1d180d0b0d0b1d0bed182d187d0b8d0bad0b8);

-- --------------------------------------------------------

-- 
-- Структура таблицы `m_data_type`
-- 

DROP TABLE IF EXISTS `m_data_type`;
CREATE TABLE `m_data_type` (
  `data_type_id` int(11) NOT NULL auto_increment,
  `sort_order` tinyint(4) NOT NULL default '0',
  `name` varchar(255) collate utf8_bin NOT NULL default '',
  `description` text collate utf8_bin NOT NULL,
  `update_script` varchar(255) collate utf8_bin NOT NULL default '',
  `edit_script` varchar(255) collate utf8_bin NOT NULL default '',
  PRIMARY KEY  (`data_type_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=8 ;

-- 
-- Дамп данных таблицы `m_data_type`
-- 

INSERT INTO `m_data_type` VALUES (1, 0, 0xd09dd0b5d0bed0bfd180d0b5d0b4d0b5d0bbd0b5d0bdd0bdd18bd0b920d182d0b8d0bf, 0xd094d0b0d0bdd0bdd18bd0b520d0bdd0b5d0bed0bfd180d0b5d0b4d0b5d0bbd0b5d0bdd0bdd0bed0b3d0be20d182d0b8d0bfd0b0, '', '');
INSERT INTO `m_data_type` VALUES (2, 1, 0xd094d0b0d0bdd0bdd18bd0b520584d4c, 0x584d4c20d0b4d0b0d0bdd0bdd18bd0b5, '', '');
INSERT INTO `m_data_type` VALUES (3, 2, 0xd094d0b0d0bdd0bdd18bd0b52048544d4c, 0xd0a7d0b8d181d182d18bd0b52048544d4c20d0b4d0b0d0bdd0bdd18bd0b5, '', '');
INSERT INTO `m_data_type` VALUES (5, 4, 0x50617273657220436f6465, 0xd09ad0bed0b420d0bdd0b020506172736572, '', '');
INSERT INTO `m_data_type` VALUES (7, 6, 0xd0a1d182d0b0d182d18cd0b8, 0xd0a1d182d0b0d182d18cd0b8, '', '');
INSERT INTO `m_data_type` VALUES (6, 5, 0x53797374656d3a6d6163726f73, 0xd0a1d0b8d181d182d0b5d0bcd0bdd18bd0b520d0bcd0b0d0bad180d0bed181d18b204d6f757365, '', '');

-- --------------------------------------------------------

-- 
-- Структура таблицы `m_lang`
-- 

DROP TABLE IF EXISTS `m_lang`;
CREATE TABLE `m_lang` (
  `lang_id` tinyint(4) NOT NULL default '0',
  `sort_order` tinyint(4) NOT NULL default '0',
  `abbr` varchar(5) collate utf8_bin NOT NULL default '',
  `charset` varchar(20) collate utf8_bin NOT NULL default '',
  PRIMARY KEY  (`lang_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='RAY: таблица языков сайта';

-- 
-- Дамп данных таблицы `m_lang`
-- 

INSERT INTO `m_lang` VALUES (1, 0, 0x7275, 0x77696e31323531);

-- --------------------------------------------------------

-- 
-- Структура таблицы `m_object`
-- 

DROP TABLE IF EXISTS `m_object`;
CREATE TABLE `m_object` (
  `object_id` int(5) unsigned NOT NULL auto_increment,
  `object_type_id` tinyint(4) NOT NULL default '0',
  `name` varchar(50) collate utf8_bin NOT NULL default '',
  `Full_Path` varchar(255) collate utf8_bin NOT NULL default '/',
  `site_id` tinyint(3) unsigned NOT NULL default '0',
  `parent_id` smallint(5) unsigned NOT NULL default '0',
  `thread_id` smallint(5) unsigned NOT NULL default '0',
  `data_process_id` tinyint(4) NOT NULL default '0',
  `template_id` tinyint(4) NOT NULL default '0',
  `rights` int(11) NOT NULL default '3',
  `cache_time` int(11) NOT NULL default '0',
  `is_show_on_sitemap` char(1) collate utf8_bin NOT NULL default '0',
  `is_show_in_menu` tinyint(4) NOT NULL default '0',
  `Path` varchar(255) collate utf8_bin NOT NULL default '',
  `url` varchar(255) collate utf8_bin NOT NULL default '',
  `link_to_object_id` int(11) NOT NULL default '0',
  `link_to_object_type_id` tinyint(4) NOT NULL default '0',
  `auser_id` int(11) NOT NULL default '0',
  `is_published` char(1) collate utf8_bin NOT NULL default '0',
  `dt_update` date NOT NULL default '0000-00-00',
  `document_name` varchar(255) collate utf8_bin NOT NULL default '',
  `window_name` varchar(255) collate utf8_bin NOT NULL default '',
  `description` varchar(255) collate utf8_bin NOT NULL default '',
  `sort_order` int(11) NOT NULL default '0',
  PRIMARY KEY  (`object_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Mouse : Хранилище объектов' AUTO_INCREMENT=86 ;

-- 
-- Дамп данных таблицы `m_object`
-- 

INSERT INTO `m_object` VALUES (1, 1, 0xd093d0bbd0b0d0b2d0bdd0b0d18f, 0x2f, 1, 0, 1, 0, 4, 3, 2, 0x31, 1, '', '', 0, 0, 0, 0x31, '2006-12-07', 0xd09dd0bed180d0b020d0bcd0b8d0bdd0bed182d0b0d0b2d180d0b0, 0xd09dd0bed180d0b020d0bcd0b8d0bdd0bed182d0b0d0b2d180d0b0, 0xd093d0bbd0b0d0b2d0bdd0b0d18f20d181d182d180d0b0d0bdd0b8d186d0b020d181d0b0d0b9d182d0b0, 2);
INSERT INTO `m_object` VALUES (2, 0, 0xd09ad0b0d180d182d0b0, 0x2f6d61702f, 1, 0, 0, 0, 4, 1, 300, 0x30, 1, 0x6d6170, '', 0, 0, 4, 0x31, '2006-11-09', 0xd09ad0b0d180d182d0b020d181d0b0d0b9d182d0b0, 0xd09ad0b0d180d182d0b020d181d0b0d0b9d182d0b0, 0xd09ad0b0d180d182d0b020d181d0b0d0b9d182d0b0, 5);
INSERT INTO `m_object` VALUES (3, 0, 0xd0a1d182d180d0b0d0bdd0b8d186d0b020d0bed188d0b8d0b1d0bed0ba, 0x2f6572726f722f, 1, 0, 3, 0, 4, 1, 300, 0x30, 0, 0x6572726f72, '', 0, 0, 4, 0x31, '2006-10-20', 0xd09ed188d0b8d0b1d0bad0b020d181d0b8d181d182d0b5d0bcd18b, 0xd09ed188d0b8d0b1d0bad0b020d181d0b8d181d182d0b5d0bcd18b, 0xd0a1d182d180d0b0d0bdd0b8d186d0b020d0bed188d0b8d0b1d0bed0ba20d181d0b8d181d182d0b5d0bcd18b, 100);
INSERT INTO `m_object` VALUES (4, 0, 0xd0a0d0b5d0b3d0b8d181d182d180d0b0d186d0b8d18f, 0x2f7265672f, 1, 0, 4, 0, 4, 1, 300, 0x31, 1, 0x726567, '', 0, 0, 4, 0x31, '0000-00-00', 0xd0a0d0b5d0b3d0b8d181d182d180d0b0d186d0b8d18f20d0bdd0bed0b2d0bed0b3d0be20d0bfd0bed0bbd18cd0b7d0bed0b2d0b0d182d0b5d0bbd18f, 0xd0a0d0b5d0b3d0b8d181d182d180d0b0d186d0b8d18f20d0bfd0bed0bbd18cd0b7d0bed0b2d0b0d182d0b5d0bbd18f, 0xd0a1d182d180d0b0d0bdd0b8d186d0b020d180d0b5d0b3d0b8d181d182d180d0b0d186d0b8d0b820d0bfd0bed0bbd18cd0b7d0bed0b2d0b0d182d0b5d0bbd0b5d0b9, 4);
INSERT INTO `m_object` VALUES (29, 2, 0x476c6f62616c, 0x2f676c6f62616c2f, 1, 0, 0, 0, 1, 1, 250, 0x30, 0, 0x676c6f62616c, '', 0, 0, 4, 0x31, '2006-10-22', 0x476c6f62616c, 0x476c6f62616c, 0xd093d0bbd0bed0b1d0b0d0bbd18cd0bdd18bd0b920d0bed0b1d18ad0b5d0bad18220d181d0bed0b4d0b5d180d0b6d0b0d189d0b8d0b920d18dd0bbd0b5d0bcd0b5d0bdd182d18b20d0b8d0bdd182d0b5d180d184d0b5d0b9d181d0b02c20d0b820d0b3d0bbd0bed0b1d0b0d0bbd18cd0bdd18bd0b520d0b1d0bbd0bed0bad0b820d0bed0b1d180d0b0d0b1d0bed182d187d0b8d0bad0b8, 0);
INSERT INTO `m_object` VALUES (24, 0, 0x4d6f757365, 0x2f6d6f7573652f, 1, 0, 0, 0, 4, 1, 250, 0x31, 1, 0x6d6f757365, '', 0, 0, 4, 0x31, '2006-11-09', 0xd0a1d0b8d181d182d0b5d0bcd0b020d183d0bfd180d0b0d0b2d0bbd0b5d0bdd0b8d18f20d0bad0bed0bdd182d0b5d0bdd182d0bed0bc, 0xd0a1d0b8d181d182d0b5d0bcd0b020d183d0bfd180d0b0d0b2d0bbd0b5d0bdd0b8d18f20d0bad0bed0bdd182d0b5d0bdd182d0bed0bc204d6f75736520434d53, 0xd0a0d0b0d0b7d0b4d0b5d0bb20d0bfd0bed181d0b2d18fd189d0b5d0bdd0bdd18bd0b920d181d0b8d181d182d0b5d0bcd0b520d183d0bfd180d0b0d0b2d0bbd0b5d0bdd0b8d18f20d0bad0bed0bdd182d0b5d0bdd182d0bed0bc20224d6f75736520434d5322, 3);
INSERT INTO `m_object` VALUES (25, 5, 0xd0a4d0bed180d183d0bc, 0x2f6d6f7573652f666f72756d2f, 1, 24, 0, 0, 4, 1, 250, 0x31, 1, 0x666f72756d, '', 0, 0, 4, 0x31, '2006-11-15', 0x4d6f75736520d184d0bed180d183d0bc, 0x4d6f75736520434d53207c20d0a4d0bed180d183d0bc, 0xd0a4d0bed180d183d0bc, 5);
INSERT INTO `m_object` VALUES (26, 0, 0xd0a1d0bad0b0d187d0b0d182d18c, 0x2f6d6f7573652f646f776e6c6f61642f, 1, 24, 24, 0, 4, 1, 250, 0x31, 0, 0x646f776e6c6f6164, '', 0, 0, 4, 0x31, '2006-11-05', 0xd097d0b0d0b3d180d183d0b7d0bad0b0204d6f75736520434d53, 0xd097d0b0d0b3d180d183d0b7d0bad0b0204d6f75736520434d53, 0xd097d0b0d0b3d180d183d0b7d0bad0b020d0b4d0b8d181d182d180d0b8d0b1d183d182d0b8d0b2d0b0204d6f75736520434d53, 7);
INSERT INTO `m_object` VALUES (27, 0, 0x4b4c654e, 0x2f6d626c6f672f, 1, 0, 0, 0, 4, 1, 250, 0x31, 1, 0x6d626c6f67, '', 0, 0, 4, 0x31, '2006-11-09', 0xd09cd0b8d0bdd0bed182d0b0d0b2d180d0bed0b220d0b1d0bbd0bed0b3, 0xd09cd0b8d0bdd0bed182d0b0d0b2d180d0bed0b220d0b1d0bbd0bed0b3, 0xd092d181d18fd0bad0b0d18f20d0b4d180d0b5d0b1d0b5d0b4d0b5d0bdd18c20d0bad0bed182d0bed180d183d18e20d0bcd0b8d0bdd0bed182d0b0d0b2d180d18b20d180d0b0d181d181d0bad0b0d0b7d18bd0b2d0b0d18ed18220d0bfd0be20d0bdd0bed187d0b0d0bc, 4);
INSERT INTO `m_object` VALUES (28, 0, 0xd094d0bed0bad183d0bcd0b5d0bdd182d0b0d186d0b8d18f, 0x2f6d6f7573652f646f632f, 1, 24, 24, 0, 4, 1, 250, 0x31, 1, 0x646f63, '', 0, 0, 4, 0x31, '2006-11-05', 0xd094d0bed0bad183d0bcd0b5d0bdd182d0b0d186d0b8d18f204d6f75736520434d53, 0x4d4f555345207c20d094d0bed0bad183d0bcd0b5d0bdd182d0b0d186d0b8d18f, 0xd09ed0bfd0b8d181d0b0d0bdd0b8d0b5204d6f75736520434d53, 0);
INSERT INTO `m_object` VALUES (80, 1, 0x41646d696e436f6e74726f6c, 0x2f6d632f61646d696e2f, 1, 79, 0, 0, 5, 0, 250, 0x30, 0, 0x61646d696e, '', 0, 0, 0, 0x31, '2006-12-07', 0xd090d0b4d0bcd0b8d0bdd0bad0b0, 0xd090d0b4d0bcd0b8d0bdd0bad0b0, 0xd09ed181d0bdd0bed0b2d0bdd0bed0b920d0b8d0bdd182d0b5d180d184d0b5d0b9d18120d0b0d0b4d0bcd0b8d0bdd0bad0b8, 1);
INSERT INTO `m_object` VALUES (79, 1, 0x41646d696e, 0x2f6d632f, 1, 0, 0, 0, 4, 0, 250, 0x31, 1, 0x6d63, '', 0, 0, 0, 0x31, '2006-12-07', 0xd090d0b4d0bcd0b8d0bdd0b8d181d182d180d0b8d180d0bed0b2d0b0d0bdd0b8d0b5204d6f75736520434d53, 0xd090d0b4d0bcd0b8d0bdd0b8d181d182d180d0b8d180d0bed0b2d0b0d0bdd0b8d0b5204d6f75736520434d53, 0xd0a2d0b5d181d182d0bed0b2d18bd0b920d0bed0b1d18ad0b5d0bad18220d18120d0bdd0b5d0b7d0b0d0b2d0b8d181d0b8d0bcd18bd0bc20d0bed0b1d180d0b0d0b1d0bed182d187d0b8d0bad0bed0bc3a20746573742e70, 0);
INSERT INTO `m_object` VALUES (85, 1, 0xd0a2d0b5d181d182d0bed0b2d18bd0b9, 0x2f746573742f, 1, 0, 0, 0, 14, 7, 5, 0x31, 1, 0x74657374, '', 0, 0, 0, 0x31, '2006-12-06', 0xd0a2d0b5d181d182d0bed0b2d0b0d18f20d181d182d180d0b0d0bdd0b8d186d0b0, 0xd0a2d0b5d181d182d18b20d181d0b8d181d182d0b5d0bcd18b, 0xd09ed0b1d18ad0b5d0bad18220d0b4d0bbd18f20d0bed182d0bbd0b0d0b4d0bad0b820d0b1d0bbd0bed0bad0bed0b220d181d0b8d181d182d0b5d0bcd18b, 99);

-- --------------------------------------------------------

-- 
-- Структура таблицы `m_object_type`
-- 

DROP TABLE IF EXISTS `m_object_type`;
CREATE TABLE `m_object_type` (
  `object_type_id` tinyint(4) NOT NULL auto_increment,
  `sort_order` tinyint(4) NOT NULL default '0',
  `is_show_on_sitemap` char(1) collate utf8_bin NOT NULL default '1',
  `is_fake` char(1) collate utf8_bin NOT NULL default '0',
  `abbr` varchar(10) collate utf8_bin NOT NULL default '',
  `name` varchar(40) collate utf8_bin NOT NULL default '',
  `constructor` varchar(40) collate utf8_bin NOT NULL default '',
  PRIMARY KEY  (`object_type_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=7 ;

-- 
-- Дамп данных таблицы `m_object_type`
-- 

INSERT INTO `m_object_type` VALUES (1, 0, 0x31, 0x30, 0x6e756c6c, 0xd09dd0b5d0bed0bfd180d0b5d0b4d0b5d0bbd0b5d0bdd0bdd18bd0b920d182d0b8d0bf, 0x6e756c6c);
INSERT INTO `m_object_type` VALUES (2, 0, 0x31, 0x30, 0x676c6f62616c, 0xd093d0bbd0bed0b1d0b0d0bbd18cd0bdd18bd0b920d0bed0b1d18ad0b5d0bad182, 0x676c6f62616c);
INSERT INTO `m_object_type` VALUES (3, 1, 0x31, 0x30, 0x756e69, 0xd0a3d0bdd0b8d0bad0b0d0bbd18cd0bdd18bd0b920d0bed0b1d18ad0b5d0bad182, 0x756e69);
INSERT INTO `m_object_type` VALUES (4, 2, 0x31, 0x30, 0x636f6e7461696e6572, 0x636f6e7461696e6572, 0x636f6e7461696e6572);
INSERT INTO `m_object_type` VALUES (5, 3, 0x31, 0x30, 0x61646d696e, 0xd09ed0b1d18ad0b5d0bad182d18b20d090d0b4d0bcd0b8d0bdd0b8d181d182d180d0b8d180d0bed0b2d0b0d0bdd0b8d18f, 0x73797374656d);
INSERT INTO `m_object_type` VALUES (6, 4, 0x31, 0x30, 0x6c697665, 0xd09ed0b1d18ad0b5d0bad182d18b20d0bed0b1d189d0b5d0b3d0be20d182d0b8d0bfd0b0, 0x6c697665);

-- --------------------------------------------------------

-- 
-- Структура таблицы `m_site`
-- 

DROP TABLE IF EXISTS `m_site`;
CREATE TABLE `m_site` (
  `site_id` int(11) NOT NULL auto_increment,
  `lang_id` tinyint(4) NOT NULL default '0',
  `sort_order` tinyint(4) NOT NULL default '0',
  `cache_time` int(4) NOT NULL default '0',
  `e404_object_id` int(11) NOT NULL default '0',
  `name` varchar(255) collate utf8_bin NOT NULL default '',
  `domain` varchar(255) collate utf8_bin NOT NULL default '',
  PRIMARY KEY  (`site_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='RAY: Таблица сайтов' AUTO_INCREMENT=3 ;

-- 
-- Дамп данных таблицы `m_site`
-- 

INSERT INTO `m_site` VALUES (1, 1, 3, 250, 3, 0x4d6f757365, 0x7777772e6d6f7573652e7275);

-- --------------------------------------------------------

-- 
-- Структура таблицы `m_template`
-- 

DROP TABLE IF EXISTS `m_template`;
CREATE TABLE `m_template` (
  `template_id` int(11) NOT NULL auto_increment,
  `sort_order` tinyint(4) NOT NULL default '0',
  `template_type_id` tinyint(4) NOT NULL default '0',
  `dt_update` date NOT NULL default '0000-00-00',
  `name` varchar(50) collate utf8_bin NOT NULL default '',
  `filename` varchar(100) collate utf8_bin NOT NULL default '',
  `params` varchar(100) collate utf8_bin NOT NULL default '',
  `description` varchar(255) collate utf8_bin NOT NULL default '',
  PRIMARY KEY  (`template_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=15 ;

-- 
-- Дамп данных таблицы `m_template`
-- 

INSERT INTO `m_template` VALUES (14, 3, 0, '2006-11-15', 0x4d6f7573652065617379, 0x4d6f7573652f6d61696e5f656173792e78736c, 0x2f7468656d65732f6d6f7573652f6373732f6d6f7573652e637373, 0xd09fd180d0bed181d182d0bed0b920d0b1d0b5d0b720d188d0b0d0bfd0bad0b820d0b220d0bed0b4d0bdd18320d0bad0bed0bbd0bed0bdd0bad183);
INSERT INTO `m_template` VALUES (4, 4, 1, '0000-00-00', 0x4d6f757365, 0x4d6f7573652f6d61696e2e78736c, 0x2f7468656d65732f6d6f7573652f6373732f6d6f7573652e637373, 0xd0a2d0b5d0bcd0b0204d6f757365);
INSERT INTO `m_template` VALUES (5, 5, 1, '2006-11-15', 0x4d6f75736520616a6178, 0x4d6f7573652f656173792e78736c, 0x2f7468656d65732f6d6f7573652f6373732f6d6f7573652e637373, 0xd0a2d0b5d0bcd0b0204d6f75736520d0a3d0bfd180d0bed189d0b5d0bdd0bdd0b0d18f);

-- --------------------------------------------------------

-- 
-- Структура таблицы `m_template_group`
-- 

DROP TABLE IF EXISTS `m_template_group`;
CREATE TABLE `m_template_group` (
  `template_group_id` int(11) NOT NULL auto_increment,
  `sort_order` tinyint(4) NOT NULL default '0',
  `directory_name` varchar(255) collate utf8_bin NOT NULL default '',
  `name` varchar(50) collate utf8_bin NOT NULL default '',
  `description` varchar(255) collate utf8_bin NOT NULL default '',
  PRIMARY KEY  (`template_group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=1 ;

-- 
-- Дамп данных таблицы `m_template_group`
-- 

        